plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.phoneshare.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.phoneshare.app"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1-m2"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // WebRTC（Google 官方最后一次发布到 Google Maven 的版本，较旧但稳定；以后要换新库只改这一行和 RtcSession.kt）
    implementation("org.webrtc:google-webrtc:1.0.32006")
}
